
fetchUsers();

function fetchUsers() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        loadUsers(this.responseText);
      }
    };
    xhttp.open("GET", "https://647456cd7de100807b1aace5.mockapi.io/users", true);
    xhttp.send();
  }
  
  function loadUsers(ok){

      let users=JSON.parse(ok);
    
      for(let i=0;i<users.length;i++){
        let html=`<div class="row" index=${users[i].id}>
    <div class="divName"><input class="name inputDefault" type="text" value="${users[i].name}"></div>
    <div class="divAge"> <input class="age inputDefault" type="text" value=${users[i].age}></div>
    <div class="divState"><input class="state inputDefault" type="text"value="${users[i].state}">
    <select class="sel bt3-remove">
    <option value="${users[i].state}">Select State</option>
    <option value="-" disabled selected hidden>Select State</option>
    <option value="Andhra Pradesh">Andhra Pradesh</option>
    <option value="Arunachal Pradesh">Arunachal Pradesh</option>
    <option value="Assam">Assam</option>
    <option value="Bihar">Bihar</option>
    <option value="Chhattisgarh">Chhattisgarh</option>
    <option value="Goa">Goa</option>
    <option value="Gujarat">Gujarat</option>
    <option value="Haryana">Haryana</option>
    <option value="Himachal Pradesh">Himachal Pradesh</option>
    <option value="Jharkhand">Jharkhand</option>
    <option value="Karnataka">Karnataka</option>
    <option value="Kerala">Kerala</option>
    <option value="Madhya Pradesh">Madhya Pradesh</option>
    <option value="Maharashtra">Maharashtra</option>
    <option value="Manipur">Manipur</option>
      </select>
    </div>
    <div class="divBtn" style="width: 20%;"><button class="edit" onclick="updateUser(this)"><i class="fa-solid fa-pen fa-xl" style="color: #000000;"></i></button> 
    <button class="delete" onclick="deleteUser(this)"><i class="fa-solid fa-trash-can fa-xl" style="color: #ffffff;"></i></button>
    <button class="enter bt3-remove" onclick="Enter(this)"><i class="fa-solid fa-cloud-arrow-up fa-lg" style="color: #ffffff;"></i></button></div>
</div>`

let ok=document.getElementById('main');
ok.innerHTML+=html;
      }

  }
  function Enter(y){
        let x=y.parentElement.parentElement;
      let name=x.querySelector('.name'); name.classList.add('inputDefault');
      let age=x.querySelector('.age');    age.classList.add('inputDefault');
      let state=x.querySelector('.state');    state.classList.remove('bt3-remove');
      let sel=x.querySelector('.sel');
      state.value=sel.value;
      sel.classList.add('bt3-remove') 
      let enter=x.querySelector('.enter'); enter.classList.add('bt3-remove')
    let user={
        "name":name.value,
        "age":age.value,
        "state":state.value
    };
   
    let k= x.getAttribute("index");
    
    var xhttp=new XMLHttpRequest();
    xhttp.onreadystatechange=function(){if(this.readyState==4&&this.status==200){alert("update sucessfull");}
};
xhttp.open("PUT","https://647456cd7de100807b1aace5.mockapi.io/users/"+k,true);
xhttp.setRequestHeader("Content-type","application/json");
xhttp.send(JSON.stringify(user));

  }
  
  function updateUser(element){
      let x=element.parentElement.parentElement;
      let name=x.querySelector('.name'); name.classList.remove('inputDefault');
      let age=x.querySelector('.age');    age.classList.remove('inputDefault');
      let sel=x.querySelector('.sel'); sel.classList.remove('bt3-remove');
      let state=x.querySelector('.state');    state.classList.add('bt3-remove');
      let enter=x.querySelector('.enter'); enter.classList.remove('bt3-remove')
     
  
  }

  function deleteUser(element){
    
    let id=element.parentElement.parentElement.getAttribute('index');
    var xhttp=new XMLHttpRequest();
    xhttp.onreadystatechange=function(){if(this.readyState==4&&this.status==200){
        let delRow=document.querySelector(`div[index="${id}"]`);
       if(delRow){
        delRow.remove();
        alert("Delete Sucessfully");
       }
    }};
    xhttp.open("DELETE","https://647456cd7de100807b1aace5.mockapi.io/users/"+id,true);
    xhttp.setRequestHeader("Content-type","application/json");
    xhttp.send();}