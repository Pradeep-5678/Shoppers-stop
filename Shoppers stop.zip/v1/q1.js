const express=require('express');
const app = express();
const bodyParser = require('body-parser');
const path=require('path');
const mongoose=require('mongoose');
mongoose.connect("mongodb://127.0.0.1:27017/ecom").then(()=>console.log("sucess")).catch((err)=>console.log(err));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.set("view engine","ejs");
app.use(express.static('public'))

// Enable CORS middleware
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', 'http://127.0.0.1:5500');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
  next();
});

const userSchema=mongoose.Schema({
  name:{
    type:String
  },
  username:{
    type:String
    
  },
  password:{
    type:String
  },
  age:{
    type:Number
  },
  state:{
    type:String
  }});

const user=mongoose.model('users',userSchema);

let x= new user({
  name:"ok",
  age:1,
  state:"foen"
});
//x.save();



const read=async(A)=>{
  const foundUser =  await user.findOne({ username:A }).exec(); 
  if(foundUser==null)return 0;
  else return foundUser;
}

app.get('/Mlogin', (req, res) => {
  res.render('login');
});

app.get('/Mreg', (req, res) => {
  res.render('reg');
});

app.get('/Mhome', (req, res) => {
  res.render('home');
});

app.get('/check',(req,res)=>{
  res.render('home');
})

app.post('/login',(req,res)=>{

  const data=req.body;
  
  read(data.username).then((rest)=>{
    console.log(data.password);
    if(rest==0)
    res.sendStatus(500);
    else if(rest.password!=data.password) res.sendStatus(500);
   else { 
    
   //res.redirect('/Mhome')
   res.render('home',{userData:rest});
   }
  });

});

app.get('/home',(req,res)=>{
  res.render('home');
})

app.post('/register',(req,res)=>{
  console.log(req.body);
  let x= new user({
    name:req.body.name,
    username:req.body.username,
    password:req.body.password,
    age:req.body.age,
    state:req.body.state
  });
  x.save();
  res.sendStatus(200);
})
app.use('/payment.html',express.static(path.join(__dirname,'product','payment.html')));
app.use('/sucess.html',express.static(path.join(__dirname,'product','sucess.html')));
app.listen(5000, () => {
  console.log(`Server is running on port `);
});